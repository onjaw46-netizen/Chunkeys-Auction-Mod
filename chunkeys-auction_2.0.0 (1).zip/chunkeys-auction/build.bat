@echo off
if "%JAVA_HOME%"=="" set "JAVA_HOME=C:\Program Files\Java\jdk-21.0.12.1"
call gradlew.bat build
echo.
echo Jar is in build\libs\chunkeys-auction-2.0.0.jar
pause
