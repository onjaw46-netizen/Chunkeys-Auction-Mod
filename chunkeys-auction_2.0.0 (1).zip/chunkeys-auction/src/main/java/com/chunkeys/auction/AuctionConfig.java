package com.chunkeys.auction;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class AuctionConfig {
    /** Group 1 = player name, group 2 = amount. Change in-game with /auction regex <pattern>. */
    public static final String DEFAULT_REGEX =
            "(\\w{1,16})\\s+(?:has\\s+)?(?:paid|payed|sent|gave)\\s+you\\s+\\$?\\s*([\\d.,]+\\s?[kKmMbBtT]?)";
    /** Auction-house sale lines, e.g. "Bob bought your Diamond Sword for $500". Group 1 = buyer, group 2 = price. */
    public static final String DEFAULT_SALE_REGEX =
            "(\\w{1,16})\\s+(?:has\\s+)?(?:bought|purchased)\\s+.*?\\bfor\\s+\\$?\\s*([\\d.,]+\\s?[kKmMbBtT]?)";
    private static final String PREV_PAY_REGEX =
            "(\\w{1,16})\\s+(?:has\\s+)?(?:paid|payed|sent|gave)\\s+you\\s+\\$?([\\d.,]+\\s?[kKmMbBtT]?)";
    private static final String PREV_SALE_REGEX =
            "(\\w{1,16})\\s+(?:has\\s+)?(?:bought|purchased)\\s+.*?\\bfor\\s+\\$?([\\d.,]+\\s?[kKmMbBtT]?)";
    private static final String OLD_DEFAULT_REGEX =
            "^(?:\\[[^\\]]*\\]\\s*)?(\\w{1,16}) (?:paid|sent) you \\$?([\\d.,]+\\s?[kKmMbBtT]?)";

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    public String payRegex = DEFAULT_REGEX;
    public String saleRegex = DEFAULT_SALE_REGEX;
    public boolean countSales = true;    // auction-house sales count like payments
    public boolean ignoreOwnBuys = true; // never count things I buy from the auction house / shop
    public boolean readActionBar = true; // also read messages shown above the hotbar
    public boolean announce = false;    // also send updates to public chat
    public boolean cumulative = false;  // count each player's payments as a running total
    public boolean hud = true;
    public boolean debug = false;       // print pay-looking chat lines so you can see what the server sends

    public enum Anchor { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }
    public Anchor hudAnchor = Anchor.TOP_LEFT;
    public int hudX = 6;   // distance from the anchored side edge
    public int hudY = 6;   // distance from the anchored top/bottom edge

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("chunkeys-auction.json");
    }

    public static AuctionConfig load() {
        try {
            if (Files.exists(path())) {
                try (Reader r = Files.newBufferedReader(path())) {
                    AuctionConfig c = GSON.fromJson(r, AuctionConfig.class);
                    if (c != null) {
                        if (c.payRegex == null || c.payRegex.isBlank()) c.payRegex = DEFAULT_REGEX;
                        if (c.saleRegex == null || c.saleRegex.isBlank()) c.saleRegex = DEFAULT_SALE_REGEX;
                        if (c.hudAnchor == null) c.hudAnchor = Anchor.TOP_LEFT;
                        if (OLD_DEFAULT_REGEX.equals(c.payRegex) || PREV_PAY_REGEX.equals(c.payRegex)) { c.payRegex = DEFAULT_REGEX; c.save(); }
                        if (PREV_SALE_REGEX.equals(c.saleRegex)) { c.saleRegex = DEFAULT_SALE_REGEX; c.save(); }
                        return c;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        AuctionConfig c = new AuctionConfig();
        c.save();
        return c;
    }

    public void save() {
        try (Writer w = Files.newBufferedWriter(path())) {
            GSON.toJson(this, w);
        } catch (IOException ignored) {
        }
    }
}
