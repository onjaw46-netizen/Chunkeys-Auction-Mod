package com.chunkeys.auction;

import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Auction {
    public enum Result { NEW_HIGH, BELOW_MIN, NOT_HIGHER }

    public final ItemStack stack;
    public final double minimum;
    /** how many of the item are being sold */
    public int count = 1;
    /** what the server says one is worth (from the item tooltip, e.g. "~$ 12K"), or typed; -1 = unknown */
    public double worth = -1;
    public long endMs;
    public long totalMs;

    public String highestBidder;
    public double highestAmount;

    public String lastPaidName;
    public double lastPaidAmount;
    public Result lastResult;

    public boolean ended;
    public long endedAtMs;

    public final Map<String, Double> totals = new HashMap<>();
    public final Set<Integer> warned = new HashSet<>();

    public Auction(ItemStack stack, long durationMs, double minimum) {
        this.stack = stack;
        this.minimum = minimum;
        this.totalMs = durationMs;
        this.endMs = System.currentTimeMillis() + durationMs;
    }

    public long timeLeftMs() {
        return ended ? 0 : Math.max(0, endMs - System.currentTimeMillis());
    }

    /**
     * Every payment becomes "last paid". It only becomes the highest bidder if it is
     * at least the minimum AND higher than the current highest bid.
     */
    public Result pay(String name, double amount, boolean cumulative) {
        lastPaidName = name;
        lastPaidAmount = amount;

        double effective = amount;
        if (cumulative) {
            effective = totals.merge(name.toLowerCase(Locale.ROOT), amount, Double::sum);
        }

        Result r;
        if (effective < minimum) {
            r = Result.BELOW_MIN;
        } else if (highestBidder != null && effective <= highestAmount) {
            r = Result.NOT_HIGHER;
        } else {
            highestBidder = name;
            highestAmount = effective;
            r = Result.NEW_HIGH;
        }
        lastResult = r;
        return r;
    }

    // ---------- helpers ----------

    public static long parseDuration(String in) {
        String s = in.trim().toLowerCase(Locale.ROOT).replace(" ", "");
        Matcher clock = Pattern.compile("(?:(\\d+):)?(\\d+):(\\d+)").matcher(s);
        if (clock.matches()) {   // 1:30 or 1:02:03
            long h = clock.group(1) == null ? 0 : Long.parseLong(clock.group(1));
            return (h * 3600 + Long.parseLong(clock.group(2)) * 60 + Long.parseLong(clock.group(3))) * 1000L;
        }
        Matcher m = Pattern.compile("(\\d+)([smhd]?)").matcher(s);
        long total = 0;
        int pos = 0;
        while (m.find()) {
            if (m.start() != pos) throw new IllegalArgumentException("bad time");
            long n = Long.parseLong(m.group(1));
            switch (m.group(2)) {
                case "m" -> n *= 60;
                case "h" -> n *= 3600;
                case "d" -> n *= 86400;
                default -> { }
            }
            total += n;
            pos = m.end();
        }
        if (pos == 0 || pos != s.length()) throw new IllegalArgumentException("bad time");
        return total * 1000L;
    }

    public static double parseAmount(String in) {
        String s = in.trim().toLowerCase(Locale.ROOT)
                .replace("$", "").replace(",", "").replace("_", "").replace(" ", "");
        while (s.endsWith(".")) s = s.substring(0, s.length() - 1);
        double mult = 1;
        if (!s.isEmpty()) {
            switch (s.charAt(s.length() - 1)) {
                case 'k' -> mult = 1e3;
                case 'm' -> mult = 1e6;
                case 'b' -> mult = 1e9;
                case 't' -> mult = 1e12;
                default -> { }
            }
        }
        if (mult != 1) s = s.substring(0, s.length() - 1);
        double v = Double.parseDouble(s) * mult;
        if (Double.isNaN(v) || Double.isInfinite(v)) throw new NumberFormatException();
        return v;
    }

    /** 90000 -> "1m 30s" */
    public static String durationText(long ms) {
        long s = ms / 1000;
        long d = s / 86400, h = (s % 86400) / 3600, m = (s % 3600) / 60, sec = s % 60;
        StringBuilder b = new StringBuilder();
        if (d > 0) b.append(d).append("d ");
        if (h > 0) b.append(h).append("h ");
        if (m > 0) b.append(m).append("m ");
        if (sec > 0 || b.length() == 0) b.append(sec).append("s");
        return b.toString().trim();
    }

    public static String money(double v) {
        if (v == Math.rint(v)) return "$" + String.format(Locale.US, "%,d", (long) v);
        return "$" + String.format(Locale.US, "%,.2f", v);
    }

    public static String time(long ms) {
        long s = (ms + 999) / 1000;
        long h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        if (h > 0) return String.format(Locale.US, "%d:%02d:%02d", h, m, sec);
        return String.format(Locale.US, "%02d:%02d", m, sec);
    }
}
