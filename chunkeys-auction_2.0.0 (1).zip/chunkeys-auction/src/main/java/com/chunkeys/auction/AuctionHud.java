package com.chunkeys.auction;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;

public class AuctionHud {
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFFAAAAAA;
    private static final int GOLD = 0xFFFFAA00;
    private static final int GREEN = 0xFF55FF55;
    private static final int RED = 0xFFFF5555;
    private static final int AQUA = 0xFF55FFFF;

    public static void render(GuiGraphics g, DeltaTracker delta) {
        Auction a = AuctionMod.current;
        if (a == null || !AuctionMod.config.hud) return;
        try {
            draw(g, a);
        } catch (Throwable t) {
            // never let the overlay take the game down: switch it off and log why
            AuctionMod.config.hud = false;
            AuctionMod.config.save();
            com.mojang.logging.LogUtils.getLogger().error("[Chunkeys Auction] HUD crashed, disabled it", t);
            AuctionMod.say(AuctionMod.lit("[Auction] HUD hit an error and was turned off (see logs/latest.log).",
                    net.minecraft.ChatFormatting.RED));
        }
    }

    /** Draws the panel at the configured anchor/offset. Also used for the position preview. */
    public static void draw(GuiGraphics g, Auction a) {
        Minecraft mc = Minecraft.getInstance();
        Font font = mc.font;

        List<String> lines = new ArrayList<>();
        List<Integer> colors = new ArrayList<>();

        String title = AuctionMod.itemName(a) + (a.ended ? "  [ENDED]" : "");
        long left = a.timeLeftMs();

        if (a.ended) {
            if (a.highestBidder != null) {
                lines.add("SOLD to " + a.highestBidder + " for " + Auction.money(a.highestAmount));
                colors.add(GOLD);
            } else {
                lines.add("No valid bids");
                colors.add(RED);
            }
        } else {
            lines.add("Time left: " + Auction.time(left));
            colors.add(left <= 10_000 ? RED : AQUA);
        }
        lines.add("Minimum: " + Auction.money(a.minimum));
        colors.add(GREEN);

        lines.add("Highest bidder: " + (a.highestBidder == null
                ? "none yet" : a.highestBidder + " (" + Auction.money(a.highestAmount) + ")"));
        colors.add(a.highestBidder == null ? GRAY : GOLD);
        lines.add("Last paid: " + (a.lastPaidName == null
                ? "none yet" : a.lastPaidName + " (" + Auction.money(a.lastPaidAmount) + ")" + AuctionMod.lastNote(a)));
        colors.add(a.lastResult == Auction.Result.BELOW_MIN ? RED : WHITE);

        String worthTag = a.worth >= 0 ? "  Worth ~" + Auction.money(a.worth) : "";
        int width = font.width(title) + font.width(worthTag) + 24;
        for (String l : lines) width = Math.max(width, font.width(l));
        width += 10;
        int height = 26 + lines.size() * 11 + 2;

        AuctionConfig c = AuctionMod.config;
        int x = switch (c.hudAnchor) {
            case TOP_RIGHT, BOTTOM_RIGHT -> g.guiWidth() - width - c.hudX;
            default -> c.hudX;
        };
        int y = switch (c.hudAnchor) {
            case BOTTOM_LEFT, BOTTOM_RIGHT -> g.guiHeight() - height - c.hudY;
            default -> c.hudY;
        };
        g.fill(x, y, x + width, y + height, 0xAA000000);
        g.renderItem(a.stack, x + 4, y + 4);
        g.drawString(font, title, x + 24, y + 8, WHITE, true);
        if (!worthTag.isEmpty()) g.drawString(font, worthTag, x + 24 + font.width(title), y + 8, GOLD, true);

        int ly = y + 26;
        for (int i = 0; i < lines.size(); i++) {
            g.drawString(font, lines.get(i), x + 5, ly, colors.get(i), true);
            ly += 11;
        }
    }
}
