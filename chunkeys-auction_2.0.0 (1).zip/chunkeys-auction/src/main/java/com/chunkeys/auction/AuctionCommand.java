package com.chunkeys.auction;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.arguments.item.ItemArgument;
import net.minecraft.commands.arguments.item.ItemInput;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.function.Consumer;
import java.util.function.Supplier;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class AuctionCommand {

    public static void register(CommandDispatcher<FabricClientCommandSource> d, CommandBuildContext access) {
        d.register(literal("auction")
                .executes(ctx -> {
                    AuctionMod.openGuiNext = true;
                    return 1;
                })
                .then(literal("gui").executes(ctx -> {
                    AuctionMod.openGuiNext = true;
                    return 1;
                }))
                // /auction start <item> <time> <minimum>
                .then(literal("start")
                        .then(argument("item", ItemArgument.item(access))
                                .then(argument("time", StringArgumentType.word())
                                        .then(argument("minimum", StringArgumentType.word())
                                                .executes(ctx -> {
                                                    ItemStack stack = ctx.getArgument("item", ItemInput.class)
                                                            .createItemStack(1, false);
                                                    return start(ctx.getSource(), stack,
                                                            StringArgumentType.getString(ctx, "time"),
                                                            StringArgumentType.getString(ctx, "minimum"), 1);
                                                })
                                                .then(argument("count", IntegerArgumentType.integer(1, 999999))
                                                        .executes(ctx -> {
                                                            ItemStack stack = ctx.getArgument("item", ItemInput.class)
                                                                    .createItemStack(1, false);
                                                            return start(ctx.getSource(), stack,
                                                                    StringArgumentType.getString(ctx, "time"),
                                                                    StringArgumentType.getString(ctx, "minimum"),
                                                                    IntegerArgumentType.getInteger(ctx, "count"));
                                                        }))))))
                // /auction hand <time> <minimum>  (uses the item in your main hand)
                .then(literal("hand")
                        .then(argument("time", StringArgumentType.word())
                                .then(argument("minimum", StringArgumentType.word())
                                        .executes(ctx -> {
                                            Minecraft mc = Minecraft.getInstance();
                                            ItemStack held = mc.player == null ? ItemStack.EMPTY : mc.player.getMainHandItem();
                                            return start(ctx.getSource(), held.copyWithCount(1),
                                                    StringArgumentType.getString(ctx, "time"),
                                                    StringArgumentType.getString(ctx, "minimum"),
                                                    Math.max(1, held.getCount()));
                                        })
                                        .then(argument("count", IntegerArgumentType.integer(1, 999999))
                                                .executes(ctx -> {
                                                    Minecraft mc = Minecraft.getInstance();
                                                    ItemStack held = mc.player == null ? ItemStack.EMPTY : mc.player.getMainHandItem();
                                                    return start(ctx.getSource(), held.copyWithCount(1),
                                                            StringArgumentType.getString(ctx, "time"),
                                                            StringArgumentType.getString(ctx, "minimum"),
                                                            IntegerArgumentType.getInteger(ctx, "count"));
                                                })))))
                .then(literal("status").executes(ctx -> {
                    Auction a = AuctionMod.current;
                    if (a == null) {
                        ctx.getSource().sendError(Component.literal("No auction running."));
                        return 0;
                    }
                    for (Component c : AuctionMod.statusLines(a)) ctx.getSource().sendFeedback(c);
                    return 1;
                }))
                .then(literal("stop").executes(ctx -> {
                    if (AuctionMod.current == null || AuctionMod.current.ended) {
                        ctx.getSource().sendError(Component.literal("No auction running."));
                        return 0;
                    }
                    AuctionMod.finish();
                    return 1;
                }))
                .then(literal("cancel").executes(ctx -> {
                    if (AuctionMod.current == null) {
                        ctx.getSource().sendError(Component.literal("No auction running."));
                        return 0;
                    }
                    AuctionMod.cancel();
                    return 1;
                }))
                .then(literal("extend")
                        .then(argument("time", StringArgumentType.word()).executes(ctx -> {
                            if (AuctionMod.current == null || AuctionMod.current.ended) {
                                ctx.getSource().sendError(Component.literal("No auction running."));
                                return 0;
                            }
                            try {
                                AuctionMod.extend(Auction.parseDuration(StringArgumentType.getString(ctx, "time")));
                            } catch (Exception e) {
                                ctx.getSource().sendError(Component.literal("Bad time. Use e.g. 30s, 5m, 1h30m"));
                                return 0;
                            }
                            return 1;
                        })))
                // /auction test <player> <amount>  (fake a payment to try it out)
                .then(literal("test")
                        .then(argument("player", StringArgumentType.word())
                                .then(argument("amount", StringArgumentType.word()).executes(ctx -> {
                                    if (AuctionMod.current == null || AuctionMod.current.ended) {
                                        ctx.getSource().sendError(Component.literal("No auction running."));
                                        return 0;
                                    }
                                    try {
                                        AuctionMod.recordPayment(StringArgumentType.getString(ctx, "player"),
                                                Auction.parseAmount(StringArgumentType.getString(ctx, "amount")));
                                    } catch (Exception e) {
                                        ctx.getSource().sendError(Component.literal("Bad amount."));
                                        return 0;
                                    }
                                    return 1;
                                }))))
                // /auction regex [pattern|reset]
                .then(literal("regex")
                        .executes(ctx -> {
                            ctx.getSource().sendFeedback(Component.literal("Pay regex: " + AuctionMod.config.payRegex));
                            return 1;
                        })
                        .then(literal("reset").executes(ctx -> {
                            AuctionMod.setRegex(AuctionConfig.DEFAULT_REGEX);
                            ctx.getSource().sendFeedback(Component.literal("Pay regex reset to default."));
                            return 1;
                        }))
                        .then(argument("pattern", StringArgumentType.greedyString()).executes(ctx -> {
                            try {
                                AuctionMod.setRegex(StringArgumentType.getString(ctx, "pattern"));
                            } catch (Exception e) {
                                ctx.getSource().sendError(Component.literal(
                                        "Bad regex (needs group 1 = name, group 2 = amount): " + e.getMessage()));
                                return 0;
                            }
                            ctx.getSource().sendFeedback(Component.literal("Pay regex updated."));
                            return 1;
                        })))
                .then(toggle("announce", () -> AuctionMod.config.announce, v -> AuctionMod.config.announce = v,
                        "Public chat announcements"))
                .then(toggle("cumulative", () -> AuctionMod.config.cumulative, v -> AuctionMod.config.cumulative = v,
                        "Cumulative bids (add up each player's payments)"))
                .then(toggle("debug", () -> AuctionMod.config.debug, v -> AuctionMod.config.debug = v,
                        "Debug (shows pay-looking chat lines)"))
                .then(toggle("hud", () -> AuctionMod.config.hud, v -> AuctionMod.config.hud = v, "HUD"))
        );
    }

    private static int start(FabricClientCommandSource src, ItemStack stack, String time, String min, int count) {
        if (stack.isEmpty()) {
            src.sendError(Component.literal("Pick a real item (or hold one for /auction hand)."));
            return 0;
        }
        long ms;
        double minimum;
        try {
            ms = Auction.parseDuration(time);
        } catch (Exception e) {
            src.sendError(Component.literal("Bad time. Use e.g. 90, 30s, 5m, 1h30m"));
            return 0;
        }
        try {
            minimum = Auction.parseAmount(min);
        } catch (Exception e) {
            src.sendError(Component.literal("Bad minimum. Use e.g. 100, 1,000, 5k, 1.5m"));
            return 0;
        }
        if (ms <= 0 || minimum < 0) {
            src.sendError(Component.literal("Time must be above 0 and minimum can't be negative."));
            return 0;
        }
        if (AuctionMod.current != null && !AuctionMod.current.ended) {
            src.sendError(Component.literal("An auction is already running. /auction stop or /auction cancel first."));
            return 0;
        }
        AuctionMod.begin(stack, ms, minimum, count);
        return 1;
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> toggle(
            String name, Supplier<Boolean> get, Consumer<Boolean> set, String label) {
        return literal(name)
                .executes(ctx -> {
                    ctx.getSource().sendFeedback(Component.literal(label + ": " + (get.get() ? "ON" : "OFF")));
                    return 1;
                })
                .then(literal("on").executes(ctx -> {
                    set.accept(true);
                    AuctionMod.config.save();
                    ctx.getSource().sendFeedback(Component.literal(label + ": ON"));
                    return 1;
                }))
                .then(literal("off").executes(ctx -> {
                    set.accept(false);
                    AuctionMod.config.save();
                    ctx.getSource().sendFeedback(Component.literal(label + ": OFF"));
                    return 1;
                }));
    }
}
