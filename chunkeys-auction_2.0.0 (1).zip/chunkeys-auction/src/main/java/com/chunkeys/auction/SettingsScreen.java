package com.chunkeys.auction;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.Consumer;
import java.util.function.Supplier;

/** Settings page: debug, action bar, auction-house sales and both detection patterns. */
public class SettingsScreen extends Screen {
    private static final int W = 300;
    private static final int WHITE = 0xFFFFFFFF, GRAY = 0xFFAAAAAA, GREEN = 0xFF55FF55,
            RED = 0xFFFF5555, GOLD = 0xFFFFAA00;

    private final Screen parent;
    private String payText = AuctionMod.config.payRegex;
    private String saleText = AuctionMod.config.saleRegex;
    private String msg = "";
    private int msgColor = GRAY;
    private EditBox payBox, saleBox;
    private int left, top;

    public SettingsScreen(Screen parent) {
        super(Component.literal("Auction Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = Math.max(6, (height - 254) / 2);

        addRenderableWidget(toggle(left, top + 24, 147, "Debug (show pay lines)",
                () -> AuctionMod.config.debug, v -> AuctionMod.config.debug = v));
        addRenderableWidget(toggle(left + 153, top + 24, 147, "Read action bar",
                () -> AuctionMod.config.readActionBar, v -> AuctionMod.config.readActionBar = v));
        addRenderableWidget(toggle(left, top + 48, 147, "AH sales count as bids",
                () -> AuctionMod.config.countSales, v -> AuctionMod.config.countSales = v));
        addRenderableWidget(toggle(left + 153, top + 48, 147, "Announce in chat",
                () -> AuctionMod.config.announce, v -> AuctionMod.config.announce = v));
        addRenderableWidget(toggle(left, top + 72, 147, "Cumulative bids",
                () -> AuctionMod.config.cumulative, v -> AuctionMod.config.cumulative = v));
        addRenderableWidget(toggle(left + 153, top + 72, 147, "HUD",
                () -> AuctionMod.config.hud, v -> AuctionMod.config.hud = v));

        addRenderableWidget(toggle(left, top + 96, 300, "Ignore my own shop/AH purchases",
                () -> AuctionMod.config.ignoreOwnBuys, v -> AuctionMod.config.ignoreOwnBuys = v));

        payBox = new EditBox(font, left, top + 136, 190, 20, Component.literal("Payment regex"));
        payBox.setMaxLength(400);
        payBox.setValue(payText);
        payBox.setResponder(s -> payText = s);
        addRenderableWidget(payBox);
        addRenderableWidget(Button.builder(Component.literal("Apply"), b -> {
                    try { AuctionMod.setRegex(payText); ok("Payment pattern updated."); }
                    catch (Exception e) { err("Bad pattern (group 1 = name, group 2 = amount)."); }
                }).bounds(left + 194, top + 136, 50, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Reset"), b -> {
                    AuctionMod.setRegex(AuctionConfig.DEFAULT_REGEX);
                    payText = AuctionConfig.DEFAULT_REGEX;
                    payBox.setValue(payText);
                    ok("Payment pattern reset.");
                }).bounds(left + 248, top + 136, 52, 20).build());

        saleBox = new EditBox(font, left, top + 180, 190, 20, Component.literal("Sale regex"));
        saleBox.setMaxLength(400);
        saleBox.setValue(saleText);
        saleBox.setResponder(s -> saleText = s);
        addRenderableWidget(saleBox);
        addRenderableWidget(Button.builder(Component.literal("Apply"), b -> {
                    try { AuctionMod.setSaleRegex(saleText); ok("Sale pattern updated."); }
                    catch (Exception e) { err("Bad pattern (group 1 = buyer, group 2 = price)."); }
                }).bounds(left + 194, top + 180, 50, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Reset"), b -> {
                    AuctionMod.setSaleRegex(AuctionConfig.DEFAULT_SALE_REGEX);
                    saleText = AuctionConfig.DEFAULT_SALE_REGEX;
                    saleBox.setValue(saleText);
                    ok("Sale pattern reset.");
                }).bounds(left + 248, top + 180, 52, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(left + 100, top + 224, 100, 20).build());
    }

    private void ok(String s) { msg = s; msgColor = GREEN; }
    private void err(String s) { msg = s; msgColor = RED; }

    private Button toggle(int x, int y, int w, String label, Supplier<Boolean> get, Consumer<Boolean> set) {
        return Button.builder(text(label, get.get()), b -> {
            boolean nv = !get.get();
            set.accept(nv);
            AuctionMod.config.save();
            b.setMessage(text(label, nv));
        }).bounds(x, y, w, 20).build();
    }

    private static Component text(String label, boolean on) {
        return Component.literal(label + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        String title = "Auction Settings";
        g.drawString(font, title, (width - font.width(title)) / 2, top + 6, GOLD, true);
        g.drawString(font, "Payment pattern (\"X paid you $Y\")", left, top + 126, GRAY, true);
        g.drawString(font, "Auction-house sale pattern (\"X bought ... for $Y\")", left, top + 170, GRAY, true);
        if (!msg.isEmpty()) g.drawString(font, msg, left, top + 206, msgColor, true);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
