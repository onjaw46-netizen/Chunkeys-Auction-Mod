package com.chunkeys.auction;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Searches every item/block in the game by display name or id. */
public class ItemSearch {
    private static List<ItemStack> all;
    private static List<String> names;   // lowercase display names (same order as all)
    private static List<String> keys;    // "display name + id words"

    private static void init() {
        if (all != null) return;
        List<ItemStack> list = new ArrayList<>();
        for (Item item : BuiltInRegistries.ITEM) {
            if (item == Items.AIR) continue;
            list.add(item.getDefaultInstance());
        }
        list.sort(Comparator.comparing(s -> s.getHoverName().getString().toLowerCase(Locale.ROOT)));
        List<String> n = new ArrayList<>();
        List<String> k = new ArrayList<>();
        for (ItemStack s : list) {
            String name = s.getHoverName().getString().toLowerCase(Locale.ROOT);
            String path = BuiltInRegistries.ITEM.getKey(s.getItem()).getPath().replace('_', ' ');
            n.add(name);
            k.add(name + " " + path);
        }
        all = list;
        names = n;
        keys = k;
    }

    private static String norm(String q) {
        return q.toLowerCase(Locale.ROOT).replace("minecraft:", "").replace('_', ' ').trim().replaceAll("\\s+", " ");
    }

    /** All items matching every word in the query, best matches first. Empty query = everything. */
    public static List<ItemStack> search(String query) {
        init();
        String q = norm(query == null ? "" : query);
        if (q.isEmpty()) return all;
        String[] tokens = q.split(" ");
        List<ItemStack> exact = new ArrayList<>();
        List<ItemStack> starts = new ArrayList<>();
        List<ItemStack> rest = new ArrayList<>();
        for (int i = 0; i < all.size(); i++) {
            String key = keys.get(i);
            boolean ok = true;
            for (String t : tokens) {
                if (!key.contains(t)) { ok = false; break; }
            }
            if (!ok) continue;
            String name = names.get(i);
            if (name.equals(q)) exact.add(all.get(i));
            else if (name.startsWith(q)) starts.add(all.get(i));
            else rest.add(all.get(i));
        }
        exact.addAll(starts);
        exact.addAll(rest);
        return exact;
    }

    public static String idOf(ItemStack s) {
        return BuiltInRegistries.ITEM.getKey(s.getItem()).toString();
    }
}
