package com.chunkeys.auction;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Pick a corner preset and fine-tune the X / Y offset of the auction overlay. */
public class HudPositionScreen extends Screen {
    private static final String[] NAMES = {"Top Left", "Top Right", "Bottom Left", "Bottom Right"};
    private static final AuctionConfig.Anchor[] ANCHORS = {
            AuctionConfig.Anchor.TOP_LEFT, AuctionConfig.Anchor.TOP_RIGHT,
            AuctionConfig.Anchor.BOTTOM_LEFT, AuctionConfig.Anchor.BOTTOM_RIGHT};

    private final Screen parent;
    private final Button[] presets = new Button[4];
    private EditBox xBox, yBox;
    private Auction sample;

    public HudPositionScreen(Screen parent) {
        super(Component.literal("HUD Position"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int top = Math.max(10, height / 2 - 70);

        for (int i = 0; i < 4; i++) {
            final int idx = i;
            int bx = cx - 103 + (i % 2) * 106;
            int by = top + 18 + (i / 2) * 24;
            presets[i] = Button.builder(Component.literal(NAMES[i]), b -> {
                        AuctionMod.config.hudAnchor = ANCHORS[idx];
                        AuctionMod.config.hudX = 6;
                        AuctionMod.config.hudY = 6;
                        AuctionMod.config.save();
                        xBox.setValue("6");
                        yBox.setValue("6");
                        refreshPresets();
                    })
                    .bounds(bx, by, 100, 20).build();
            addRenderableWidget(presets[i]);
        }

        xBox = new EditBox(font, cx - 103, top + 84, 100, 20, Component.literal("X"));
        xBox.setMaxLength(5);
        xBox.setValue(String.valueOf(AuctionMod.config.hudX));
        xBox.setResponder(s -> {
            Integer v = parse(s);
            if (v != null) {
                AuctionMod.config.hudX = v;
                AuctionMod.config.save();
            }
        });
        addRenderableWidget(xBox);

        yBox = new EditBox(font, cx + 3, top + 84, 100, 20, Component.literal("Y"));
        yBox.setMaxLength(5);
        yBox.setValue(String.valueOf(AuctionMod.config.hudY));
        yBox.setResponder(s -> {
            Integer v = parse(s);
            if (v != null) {
                AuctionMod.config.hudY = v;
                AuctionMod.config.save();
            }
        });
        addRenderableWidget(yBox);

        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(cx - 50, top + 112, 100, 20).build());

        refreshPresets();
    }

    private static Integer parse(String s) {
        try {
            int v = Integer.parseInt(s.trim());
            return Math.max(0, Math.min(5000, v));
        } catch (Exception e) {
            return null;
        }
    }

    private void refreshPresets() {
        for (int i = 0; i < 4; i++) {
            boolean sel = AuctionMod.config.hudAnchor == ANCHORS[i];
            presets[i].setMessage(Component.literal(sel ? "> " + NAMES[i] + " <" : NAMES[i]));
        }
    }

    private Auction sample() {
        if (sample == null) {
            sample = new Auction(new ItemStack(Items.DIAMOND), 300_000L, 100);
            sample.highestBidder = "Steve";
            sample.highestAmount = 250;
            sample.lastPaidName = "Alex";
            sample.lastPaidAmount = 1;
            sample.lastResult = Auction.Result.BELOW_MIN;
        }
        return sample;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        int cx = width / 2;
        int top = Math.max(10, height / 2 - 70);

        String title = "HUD Position";
        g.drawString(font, title, cx - font.width(title) / 2, top + 4, 0xFFFFAA00, true);
        g.drawString(font, "X offset", cx - 103, top + 74, 0xFFAAAAAA, true);
        g.drawString(font, "Y offset", cx + 3, top + 74, 0xFFAAAAAA, true);

        // live overlay already shows while an auction runs; otherwise draw a sample
        if (AuctionMod.current == null || !AuctionMod.config.hud) {
            AuctionHud.draw(g, sample());
        }
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
