package com.chunkeys.auction;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Searchable grid of every item and block. Click one to pick it. */
public class ItemPickerScreen extends Screen {
    private final Screen parent;
    private final Consumer<ItemStack> onPick;
    private String query;

    private EditBox search;
    private Button prev, next;
    private final List<Button> cells = new ArrayList<>();
    private final List<ItemStack> pageItems = new ArrayList<>();
    private List<ItemStack> results = new ArrayList<>();
    private int page, cols, rows, gridLeft, gridTop;

    public ItemPickerScreen(Screen parent, String initialQuery, Consumer<ItemStack> onPick) {
        super(Component.literal("Select item"));
        this.parent = parent;
        this.query = initialQuery == null ? "" : initialQuery;
        this.onPick = onPick;
    }

    @Override
    protected void init() {
        cells.clear();
        cols = Math.max(1, Math.min(14, (width - 20) / 22));
        rows = Math.max(1, Math.min(9, (height - 36 - 50) / 22));
        gridLeft = (width - cols * 22) / 2 + 1;
        gridTop = 36;

        search = new EditBox(font, width / 2 - 100, 10, 200, 20, Component.literal("Search"));
        search.setMaxLength(60);
        search.setHint(Component.literal("Search items & blocks..."));
        search.setValue(query);
        search.setResponder(s -> {
            query = s;
            page = 0;
            refresh();
        });
        addRenderableWidget(search);
        setInitialFocus(search);

        prev = Button.builder(Component.literal("< Prev"), b -> { page--; refresh(); })
                .bounds(width / 2 - 130, height - 26, 50, 20).build();
        next = Button.builder(Component.literal("Next >"), b -> { page++; refresh(); })
                .bounds(width / 2 + 80, height - 26, 50, 20).build();
        Button cancel = Button.builder(Component.literal("Cancel"), b -> onClose())
                .bounds(width / 2 - 35, height - 26, 70, 20).build();
        addRenderableWidget(prev);
        addRenderableWidget(next);
        addRenderableWidget(cancel);

        refresh();
    }

    private int pages() {
        int per = cols * rows;
        return Math.max(1, (results.size() + per - 1) / per);
    }

    private void refresh() {
        results = ItemSearch.search(query);
        int per = cols * rows;
        page = Math.max(0, Math.min(page, pages() - 1));

        for (Button b : cells) removeWidget(b);
        cells.clear();
        pageItems.clear();

        int start = page * per;
        for (int i = 0; i < per && start + i < results.size(); i++) {
            ItemStack st = results.get(start + i);
            int cx = gridLeft + (i % cols) * 22;
            int cy = gridTop + (i / cols) * 22;
            Button b = Button.builder(Component.empty(), btn -> pick(st)).bounds(cx, cy, 20, 20).build();
            addRenderableWidget(b);
            cells.add(b);
            pageItems.add(st);
        }
        prev.active = page > 0;
        next.active = page < pages() - 1;
    }

    private void pick(ItemStack st) {
        onPick.accept(st.copyWithCount(1));
        minecraft.setScreen(parent);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (scrollY > 0 && page > 0) {
            page--;
            refresh();
            return true;
        }
        if (scrollY < 0 && page < pages() - 1) {
            page++;
            refresh();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);

        ItemStack hovered = null;
        for (int i = 0; i < pageItems.size(); i++) {
            int cx = gridLeft + (i % cols) * 22;
            int cy = gridTop + (i / cols) * 22;
            g.renderItem(pageItems.get(i), cx + 2, cy + 2);
            if (mouseX >= cx && mouseX < cx + 20 && mouseY >= cy && mouseY < cy + 20) {
                hovered = pageItems.get(i);
            }
        }

        if (pageItems.isEmpty()) {
            g.drawString(font, "No items found", gridLeft, gridTop + 4, 0xFFFF5555, true);
        }
        if (hovered != null) {
            g.drawString(font, hovered.getHoverName().getString() + "  (" + ItemSearch.idOf(hovered) + ")",
                    gridLeft, height - 40, 0xFFFFFF55, true);
        }
        String pg = "Page " + (page + 1) + "/" + pages() + "  (" + results.size() + " items)";
        g.drawString(font, pg, width - gridLeft - font.width(pg), height - 40, 0xFFAAAAAA, true);
    }

    @Override
    public void onClose() {
        minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
