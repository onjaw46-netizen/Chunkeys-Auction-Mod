package com.chunkeys.auction;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Main auction menu. Opened with the "Open Auction Menu" key (Insert by default). */
public class AuctionScreen extends Screen {
    private static final int W = 300;
    private static final int WHITE = 0xFFFFFFFF, GRAY = 0xFFAAAAAA, GREEN = 0xFF55FF55,
            RED = 0xFFFF5555, GOLD = 0xFFFFAA00, AQUA = 0xFF55FFFF;

    // kept across init() (resize / coming back from the picker)
    private String itemText = "";
    private String minText = "100";
    private String timeText = "5m";
    private String countText = "1";
    private String worthText = "";
    private String regexText = AuctionMod.config.payRegex;
    private ItemStack resolved = ItemStack.EMPTY;
    private ItemStack locked = ItemStack.EMPTY;
    private String lockedText = null;
    private int matchCount = 0;
    private String msg = "";
    private int msgColor = GRAY;

    private EditBox itemBox, minBox, timeBox, countBox, worthBox, regexBox;
    private int left, top;

    public AuctionScreen() {
        super(Component.literal("Chunkeys Auction"));
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = Math.max(6, (height - 290) / 2);

        // --- item ---
        itemBox = new EditBox(font, left, top + 24, 190, 20, Component.literal("Item"));
        itemBox.setMaxLength(100);
        itemBox.setHint(Component.literal("type e.g. netherite ingot"));
        itemBox.setValue(itemText);
        itemBox.setResponder(this::onItemText);
        addRenderableWidget(itemBox);
        onItemText(itemText);

        addRenderableWidget(Button.builder(Component.literal("Select"), b ->
                        minecraft.setScreen(new ItemPickerScreen(this, locked.isEmpty() ? itemText : lockedText, this::lock)))
                .bounds(left + 194, top + 24, 50, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Held"), b -> {
                    ItemStack hand = minecraft.player == null ? ItemStack.EMPTY
                            : minecraft.player.getMainHandItem();
                    if (hand.isEmpty()) { err("Your main hand is empty."); return; }
                    lock(hand.copyWithCount(1));
                    // use the whole stack you're holding as the amount (you can still edit it)
                    countText = String.valueOf(hand.getCount());
                    if (countBox != null) countBox.setValue(countText);
                    ok("Held: " + hand.getCount() + "x " + hand.getHoverName().getString()
                            + (worthText.isEmpty() ? "" : "  (worth ~$" + worthText + ")"));
                })
                .bounds(left + 248, top + 24, 52, 20).build());

        // --- minimum + time ---
        minBox = new EditBox(font, left, top + 82, 110, 20, Component.literal("Minimum"));
        minBox.setMaxLength(30);
        minBox.setValue(minText);
        minBox.setResponder(s -> minText = s);
        addRenderableWidget(minBox);

        timeBox = new EditBox(font, left + 116, top + 82, 90, 20, Component.literal("Time"));
        timeBox.setMaxLength(20);
        timeBox.setValue(timeText);
        timeBox.setResponder(s -> timeText = s);
        addRenderableWidget(timeBox);

        countBox = new EditBox(font, left + 212, top + 82, 88, 20, Component.literal("Amount"));
        countBox.setMaxLength(6);
        countBox.setFilter(s -> s.matches("\\d*"));
        countBox.setValue(countText);
        countBox.setResponder(s -> countText = s);
        addRenderableWidget(countBox);

        // --- worth (auto-read from the server tooltip when you use Held, or type it) ---
        worthBox = new EditBox(font, left, top + 116, 140, 20, Component.literal("Worth"));
        worthBox.setMaxLength(30);
        worthBox.setHint(Component.literal("auto from Held, or type"));
        worthBox.setValue(worthText);
        worthBox.setResponder(s -> worthText = s);
        addRenderableWidget(worthBox);
        addRenderableWidget(Button.builder(Component.literal("Set as minimum"), b -> {
                    try {
                        Auction.parseAmount(worthText);
                        minText = worthText.trim();
                        minBox.setValue(minText);
                        ok("Minimum set to " + Auction.money(Auction.parseAmount(minText)) + ".");
                    } catch (Exception e) {
                        err("No worth to use. Press Held or type one.");
                    }
                }).bounds(left + 146, top + 116, 154, 20).build());

        // --- toggles ---
        addRenderableWidget(toggle(left, top + 142, 96, "Announce",
                () -> AuctionMod.config.announce, v -> AuctionMod.config.announce = v));
        addRenderableWidget(toggle(left + 102, top + 142, 96, "Cumulative",
                () -> AuctionMod.config.cumulative, v -> AuctionMod.config.cumulative = v));
        addRenderableWidget(toggle(left + 204, top + 142, 96, "HUD",
                () -> AuctionMod.config.hud, v -> AuctionMod.config.hud = v));

        // --- regex ---
        regexBox = new EditBox(font, left, top + 178, 190, 20, Component.literal("Regex"));
        regexBox.setMaxLength(400);
        regexBox.setValue(regexText);
        regexBox.setResponder(s -> regexText = s);
        addRenderableWidget(regexBox);
        addRenderableWidget(Button.builder(Component.literal("Apply"), b -> {
                    try {
                        AuctionMod.setRegex(regexText);
                        ok("Pay regex updated.");
                    } catch (Exception e) {
                        err("Bad regex (group 1 = name, group 2 = amount).");
                    }
                })
                .bounds(left + 194, top + 178, 50, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Reset"), b -> {
                    AuctionMod.setRegex(AuctionConfig.DEFAULT_REGEX);
                    regexText = AuctionConfig.DEFAULT_REGEX;
                    regexBox.setValue(regexText);
                    ok("Pay regex reset.");
                })
                .bounds(left + 248, top + 178, 52, 20).build());

        // --- actions ---
        addRenderableWidget(Button.builder(Component.literal("Start"), b -> doStart())
                .bounds(left, top + 206, 71, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Stop"), b -> {
                    if (running()) { AuctionMod.finish(); ok("Auction stopped."); }
                    else err("No auction running.");
                })
                .bounds(left + 76, top + 206, 71, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Cancel"), b -> {
                    if (AuctionMod.current != null) { AuctionMod.cancel(); ok("Auction cancelled."); }
                    else err("No auction running.");
                })
                .bounds(left + 152, top + 206, 71, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+ Time"), b -> {
                    if (!running()) { err("No auction running."); return; }
                    try {
                        AuctionMod.extend(Auction.parseDuration(timeText));
                        ok("Extended by " + timeText + ".");
                    } catch (Exception e) {
                        err("Bad time. Use 90, 30s, 5m, 1h30m");
                    }
                })
                .bounds(left + 228, top + 206, 72, 20).build());

        addRenderableWidget(Button.builder(Component.literal("HUD Position"),
                        b -> minecraft.setScreen(new HudPositionScreen(this)))
                .bounds(left + W - 90, top - 1, 90, 14).build());

        addRenderableWidget(Button.builder(Component.literal("Settings"),
                        b -> minecraft.setScreen(new SettingsScreen(this)))
                .bounds(left, top - 1, 70, 14).build());

        setInitialFocus(itemBox);
    }

    // ---------- item handling ----------

    private void onItemText(String s) {
        itemText = s;
        if (!locked.isEmpty() && s.equals(lockedText)) {
            resolved = locked;
            matchCount = 1;
            return;
        }
        if (!locked.isEmpty()) {   // switched away from a picked/held item: its worth no longer applies
            worthText = "";
            if (worthBox != null) worthBox.setValue("");
        }
        locked = ItemStack.EMPTY;
        lockedText = null;
        if (s.isBlank()) {
            resolved = ItemStack.EMPTY;
            matchCount = 0;
            return;
        }
        List<ItemStack> r = ItemSearch.search(s);
        matchCount = r.size();
        resolved = r.isEmpty() ? ItemStack.EMPTY : r.get(0).copyWithCount(1);
    }

    /** Picked from the grid or "Held": keeps exact stack (incl. components). */
    private void lock(ItemStack st) {
        String name = st.getHoverName().getString();
        locked = st;
        lockedText = name;
        itemText = name;
        resolved = st;
        matchCount = 1;
        String w = AuctionMod.readWorth(st);
        if (w == null) w = AuctionMod.worthFromInventory(st);
        worthText = w == null ? "" : w;
        if (worthBox != null) worthBox.setValue(worthText);
        if (itemBox != null) itemBox.setValue(name);
    }

    // ---------- actions ----------

    private boolean running() {
        return AuctionMod.current != null && !AuctionMod.current.ended;
    }

    private void doStart() {
        if (resolved.isEmpty()) { err("Type an item name or click Select."); return; }
        long ms;
        double min;
        try { ms = Auction.parseDuration(timeText); }
        catch (Exception e) { err("Bad time. Use 90, 30s, 5m, 1h30m"); return; }
        try { min = Auction.parseAmount(minText); }
        catch (Exception e) { err("Bad minimum. Use 100, 1,000, 5k, 1.5m"); return; }
        if (ms <= 0 || min < 0) { err("Time must be above 0 and minimum can't be negative."); return; }
        if (running()) { err("Auction already running - Stop or Cancel it first."); return; }
        int count;
        try { count = countText.isBlank() ? 1 : Integer.parseInt(countText.trim()); }
        catch (Exception e) { err("Bad amount. Use a whole number like 5 or 10."); return; }
        if (count < 1) { err("Amount must be at least 1."); return; }
        double worth = -1;
        if (worthText.isBlank()) {   // typed an item name: try to read its worth from the same item in your inventory
            String w = AuctionMod.worthFromInventory(resolved);
            if (w != null) { worthText = w; if (worthBox != null) worthBox.setValue(w); }
        }
        if (!worthText.isBlank()) {
            try { worth = Auction.parseAmount(worthText); }
            catch (Exception e) { err("Bad worth. Use 12000, 12k, 1.5m or leave it empty."); return; }
        }
        AuctionMod.begin(resolved.copyWithCount(1), ms, min, count, worth);
        ok("Auction started!");
    }

    private void ok(String s) { msg = s; msgColor = GREEN; }
    private void err(String s) { msg = s; msgColor = RED; }

    private Button toggle(int x, int y, int w, String label, Supplier<Boolean> get, Consumer<Boolean> set) {
        return Button.builder(toggleText(label, get.get()), b -> {
            boolean nv = !get.get();
            set.accept(nv);
            AuctionMod.config.save();
            b.setMessage(toggleText(label, nv));
        }).bounds(x, y, w, 20).build();
    }

    private static Component toggleText(String label, boolean on) {
        return Component.literal(label + ": " + (on ? "ON" : "OFF"));
    }

    // ---------- render ----------

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);

        String title = "Chunkeys Auction";
        g.drawString(font, title, (width - font.width(title)) / 2, top + 2, GOLD, true);

        g.drawString(font, "Item (type a name or use Select)", left, top + 14, GRAY, true);

        // preview of what the typed name resolved to
        if (!resolved.isEmpty()) {
            g.renderItem(resolved, left, top + 46);
            String t = resolved.getHoverName().getString() + "  (" + ItemSearch.idOf(resolved) + ")";
            if (matchCount > 1) t += "  +" + (matchCount - 1) + " more";
            g.drawString(font, font.plainSubstrByWidth(t, W - 22), left + 22, top + 51, GREEN, true);
        } else if (itemText.isBlank()) {
            g.drawString(font, "No item chosen yet", left + 22, top + 51, GRAY, true);
        } else {
            g.drawString(font, "No item found for \"" + itemText + "\"", left + 22, top + 51, RED, true);
        }

        // live read-back so "1m" is never confusing: money field m = million, timer field m = minute
        String minShown;
        int minColor = GREEN;
        try {
            minShown = Auction.money(Auction.parseAmount(minText));
        } catch (Exception e) {
            minShown = "?";
            minColor = RED;
        }
        g.drawString(font, "Min: " + minShown, left, top + 72, minColor, true);
        String timeShown;
        int timeColor = AQUA;
        try {
            long ms = Auction.parseDuration(timeText);
            timeShown = ms > 0 ? Auction.durationText(ms) : "?";
            if (ms <= 0) timeColor = RED;
        } catch (Exception e) {
            timeShown = "?";
            timeColor = RED;
        }
        g.drawString(font, "Timer: " + timeShown, left + 116, top + 72, timeColor, true);
        String cntShown = "?";
        int cntColor = RED;
        try {
            int n = countText.isBlank() ? 1 : Integer.parseInt(countText.trim());
            if (n >= 1) { cntShown = "x" + n; cntColor = GOLD; }
        } catch (Exception ignored) { }
        String wShown = "none";
        int wColor = GRAY;
        if (!worthText.isBlank()) {
            try { wShown = "~" + Auction.money(Auction.parseAmount(worthText)); wColor = WHITE; }
            catch (Exception e) { wShown = "?"; wColor = RED; }
        }
        g.drawString(font, "Worth (server price): " + wShown, left, top + 106, wColor, true);
        g.drawString(font, "Amount: " + cntShown, left + 212, top + 72, cntColor, true);
        g.drawString(font, "Payment detection (regex)", left, top + 168, GRAY, true);

        if (!msg.isEmpty()) g.drawString(font, msg, left, top + 230, msgColor, true);

        // live status
        int y = top + 242;
        Auction a = AuctionMod.current;
        if (a == null) {
            g.drawString(font, "No auction running.", left, y, GRAY, true);
        } else {
            String head = AuctionMod.itemName(a) + "  -  min " + Auction.money(a.minimum)
                    + (a.ended ? "  [ENDED]" : "  -  " + Auction.time(a.timeLeftMs()) + " left");
            g.drawString(font, head, left, y, a.ended ? GOLD : AQUA, true);
            g.drawString(font, "Highest bidder: " + (a.highestBidder == null
                    ? "none yet" : a.highestBidder + " (" + Auction.money(a.highestAmount) + ")"),
                    left, y + 11, a.highestBidder == null ? GRAY : GOLD, true);
            g.drawString(font, "Last paid: " + (a.lastPaidName == null
                    ? "none yet" : a.lastPaidName + " (" + Auction.money(a.lastPaidAmount) + ")" + AuctionMod.lastNote(a)),
                    left, y + 22, a.lastResult == Auction.Result.BELOW_MIN ? RED : WHITE, true);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
