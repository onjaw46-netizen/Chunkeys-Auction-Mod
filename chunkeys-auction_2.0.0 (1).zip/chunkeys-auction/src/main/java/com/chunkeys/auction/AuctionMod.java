package com.chunkeys.auction;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class AuctionMod implements ClientModInitializer {
    public static final String MOD_ID = "chunkeysauction";
    private static final int[] WARN_SECONDS = {60, 30, 10};

    public static AuctionConfig config;
    public static Auction current;
    private static Pattern payPattern;
    private static Pattern salePattern;
    /** true while the mod itself is printing to chat, so it never reads its own messages */
    private static boolean sayingNow = false;
    private static String lastOverlay = "";
    private static long lastOverlayMs = 0;
    public static KeyMapping openKey;
    public static boolean openGuiNext;

    @Override
    public void onInitializeClient() {
        config = AuctionConfig.load();
        try {
            compilePattern();
        } catch (PatternSyntaxException e) {
            config.payRegex = AuctionConfig.DEFAULT_REGEX;
            compilePattern();
        }
        try {
            salePattern = Pattern.compile(config.saleRegex);
        } catch (PatternSyntaxException e) {
            config.saleRegex = AuctionConfig.DEFAULT_SALE_REGEX;
            salePattern = Pattern.compile(config.saleRegex);
        }

        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));
        openKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.chunkeysauction.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_INSERT, category));

        ClientCommandRegistrationCallback.EVENT.register(AuctionCommand::register);
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            tickGui(client);
            tick();
        });
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (sayingNow) return;
            String text = message.getString();
            if (overlay) {
                if (!config.readActionBar) return;
                // servers often resend the same action-bar text every second; count it once
                long now = System.currentTimeMillis();
                if (text.equals(lastOverlay) && now - lastOverlayMs < 5000) { lastOverlayMs = now; return; }
                lastOverlay = text;
                lastOverlayMs = now;
            }
            onChatLine(text);
        });
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, ts) ->
                onPlayerChatDebug(message.getString()));
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                Identifier.fromNamespaceAndPath(MOD_ID, "auction_hud"),
                AuctionHud::render);
    }

    // ---------- regex ----------

    private static void compilePattern() {
        payPattern = Pattern.compile(config.payRegex);
    }

    public static void setSaleRegex(String regex) {
        Pattern p = Pattern.compile(regex);
        if (p.matcher("").groupCount() < 2) {
            throw new PatternSyntaxException("needs 2 groups: (buyer) and (price)", regex, -1);
        }
        config.saleRegex = regex;
        config.save();
        salePattern = p;
    }

    /** Throws if the pattern is invalid or has fewer than 2 groups. */
    public static void setRegex(String regex) {
        Pattern p = Pattern.compile(regex);
        if (p.matcher("").groupCount() < 2) {
            throw new PatternSyntaxException("needs 2 groups: (name) and (amount)", regex, -1);
        }
        config.payRegex = regex;
        config.save();
        payPattern = p;
    }

    // ---------- auction lifecycle ----------

    public static void begin(ItemStack stack, long ms, double minimum) {
        begin(stack, ms, minimum, 1);
    }

    public static void begin(ItemStack stack, long ms, double minimum, int count) {
        begin(stack, ms, minimum, count, -1);
    }

    public static void begin(ItemStack stack, long ms, double minimum, int count, double worth) {
        Auction a = new Auction(stack.copyWithCount(1), ms, minimum);
        a.count = Math.max(1, count);
        if (worth < 0) {
            String w = readWorth(stack);
            if (w == null) w = worthFromInventory(stack);
            if (w != null) {
                try { worth = Auction.parseAmount(w); } catch (Exception ignored) { }
            }
        }
        a.worth = worth;
        current = a;
        say(prefix().append(lit("Auction started!", ChatFormatting.GREEN)));
        for (Component c : statusLines(a)) say(c);
        publicSay(publicSummary(a) + (a.worth >= 0 ? " | Worth ~" + Auction.money(a.worth) : "")
                + " | Pay me " + Auction.money(minimum) + "+ to bid");
    }

    public static void cancel() {
        Auction a = current;
        if (a == null) return;
        current = null;
        say(prefix().append(lit("Auction cancelled.", ChatFormatting.RED)));
        publicSay("[Auction] Cancelled.");
    }

    public static void extend(long ms) {
        Auction a = current;
        if (a == null || a.ended) return;
        a.endMs += ms;
        a.totalMs += ms;
        long left = a.timeLeftMs();
        a.warned.removeIf(s -> s * 1000L < left);
        say(prefix().append(lit("Extended. Time left: " + Auction.time(left), ChatFormatting.AQUA)));
        publicSay("[Auction] Time extended! " + Auction.time(left) + " left.");
    }

    public static void finish() {
        Auction a = current;
        if (a == null || a.ended) return;
        a.ended = true;
        a.endedAtMs = System.currentTimeMillis();

        String item = itemName(a);
        if (a.highestBidder != null) {
            String msg = "SOLD! " + item + " -> " + a.highestBidder + " for " + Auction.money(a.highestAmount);
            say(prefix().append(lit(msg, ChatFormatting.GOLD)));
            publicSay("[Auction] " + msg);
        } else {
            String msg = "Ended: no valid bids for " + item + " (minimum " + Auction.money(a.minimum) + ").";
            say(prefix().append(lit(msg, ChatFormatting.RED)));
            publicSay("[Auction] " + msg);
        }
        if (a.lastPaidName != null) {
            say(prefix().append(lit("Last paid: " + a.lastPaidName + " - " + Auction.money(a.lastPaidAmount)
                    + lastNote(a), ChatFormatting.GRAY)));
        }
        playPing();
    }

    private static void tickGui(Minecraft mc) {
        while (openKey.consumeClick()) {
            if (mc.screen == null) openGuiNext = true;
        }
        if (openGuiNext && mc.screen == null && mc.player != null) {
            openGuiNext = false;
            mc.setScreen(new AuctionScreen());
        }
    }

    private static void tick() {
        Auction a = current;
        if (a == null) return;
        long now = System.currentTimeMillis();
        if (a.ended) {
            if (now - a.endedAtMs > 20_000) current = null;
            return;
        }
        long left = a.endMs - now;
        if (left <= 0) {
            finish();
            return;
        }
        for (int s : WARN_SECONDS) {
            if (left <= s * 1000L && a.totalMs > s * 1000L && a.warned.add(s)) {
                publicSay("[Auction] " + s + "s left! " + shortStatus(a));
            }
        }
    }

    // ---------- payments ----------

    private static final Pattern ALT_AMOUNT_FIRST = Pattern.compile(
            "(?i)(?:received|got)\\s+\\$?\\s*([\\d.,]+\\s?[kmbt]?)\\s+from\\s+(\\w{1,16})");

    private static boolean looksPayRelated(String raw) {
        String l = raw.toLowerCase();
        return l.contains("$") || l.contains("paid") || l.contains("sent") || l.contains("receiv") || l.contains("gave")
                || l.contains("bought") || l.contains("purchas") || l.contains("sold");
    }

    private static boolean accept(String name, String amount) {
        if (config.ignoreOwnBuys && isMe(name)) return false;
        try {
            recordPayment(name, Auction.parseAmount(amount));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ---------- ignore my own purchases (auction house / shop) ----------

    private static final Pattern OWN_BUY = Pattern.compile(
            "(?i)\\byou\\s+(?:have\\s+|just\\s+|successfully\\s+)?(?:bought|purchased|paid|spent|bid|ordered|sent|gave)\\b"
                    + "|^\\W*(?:purchased|bought|spent)\\b");
    private static final Pattern SHOP_WORDS = Pattern.compile(
            "(?i)\\b(?:from|at|in)\\s+(?:the\\s+)?(?:server\\s+)?(?:shop|store|market|auction\\s*house|ah)\\b");
    private static final Pattern INCOMING = Pattern.compile(
            "(?i)\\b(?:paid|payed|sent|gave)\\s+you\\b|\\byour\\b");

    private static String myName() {
        try {
            return Minecraft.getInstance().getUser().getName();
        } catch (Throwable t) {
            return null;
        }
    }

    /** true if the line is me buying/paying for something (auction house, shop), not someone paying me. */
    private static boolean isOwnPurchase(String raw) {
        if (!config.ignoreOwnBuys) return false;
        if (OWN_BUY.matcher(raw).find()) return true;
        String me = myName();
        if (me != null && Pattern.compile("(?i)(?:^|[\\]\\s])" + Pattern.quote(me)
                + "\\s+(?:has\\s+)?(?:bought|purchased|spent|paid\\s+(?!you))").matcher(raw).find()) return true;
        return SHOP_WORDS.matcher(raw).find() && !INCOMING.matcher(raw).find();
    }

    private static boolean isMe(String name) {
        if (name == null) return false;
        if (name.equalsIgnoreCase("you")) return true;
        String me = myName();
        return me != null && me.equalsIgnoreCase(name);
    }

    private static boolean tryParse(String raw) {
        if (isOwnPurchase(raw)) return false;
        Matcher m = payPattern.matcher(raw);
        if (m.find() && accept(m.group(1), m.group(2))) return true;
        Matcher alt = ALT_AMOUNT_FIRST.matcher(raw);
        if (alt.find() && accept(alt.group(2), alt.group(1))) return true;
        if (config.countSales && salePattern != null) {
            Matcher sale = salePattern.matcher(raw);
            return sale.find() && accept(sale.group(1), sale.group(2));
        }
        return false;
    }

    private static void onChatLine(String raw) {
        Auction a = current;
        boolean active = a != null && !a.ended && payPattern != null;
        boolean matched = active && tryParse(raw);
        if (config.debug && looksPayRelated(raw)) {
            say(lit("[Auction debug][system] " + raw
                    + (matched ? "  -> MATCHED" : isOwnPurchase(raw) ? "  -> ignored (my own purchase)"
                    : active ? "  -> no match" : "  -> (no auction running)"),
                    ChatFormatting.DARK_AQUA));
        }
    }

    private static void onPlayerChatDebug(String raw) {
        if (sayingNow) return;
        if (config.debug && looksPayRelated(raw)) {
            say(lit("[Auction debug][player chat - ignored] " + raw, ChatFormatting.DARK_GRAY));
        }
    }

    public static void recordPayment(String name, double amount) {
        Auction a = current;
        if (a == null || a.ended) return;
        Auction.Result r = a.pay(name, amount, config.cumulative);

        MutableComponent line = prefix().append(lit(name + " paid " + Auction.money(amount), ChatFormatting.WHITE));
        switch (r) {
            case NEW_HIGH -> line.append(lit("  -> new highest bidder!", ChatFormatting.GREEN));
            case BELOW_MIN -> line.append(lit("  (below minimum - only counts as last paid)", ChatFormatting.RED));
            case NOT_HIGHER -> line.append(lit("  (not higher than " + Auction.money(a.highestAmount)
                    + " - only counts as last paid)", ChatFormatting.YELLOW));
        }
        say(line);
        publicSay(publicSummary(a));
        if (r == Auction.Result.NEW_HIGH) playPing();
    }

    // ---------- item worth (server tooltip line like "~$ 12K") ----------

    private static final Pattern WORTH_TILDE = Pattern.compile("~\\s*\\$?\\s*(\\d[\\d.,]*\\s?[kKmMbBtT]?)");
    private static final Pattern WORTH_DOLLAR = Pattern.compile("\\$\\s*(\\d[\\d.,]*\\s?[kKmMbBtT]?)");

    /** The item you typed/picked has no server lore, so look for the same item in your inventory and read its worth. */
    public static String worthFromInventory(ItemStack want) {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || want == null || want.isEmpty()) return null;
            var inv = mc.player.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack s = inv.getItem(i);
                if (!s.isEmpty() && ItemStack.isSameItem(s, want)) {
                    String w = readWorth(s);
                    if (w != null) return w;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Reads the worth the server prints in the item's tooltip/lore. Returns e.g. "12K", or null if none. */
    public static String readWorth(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;
        try {
            Minecraft mc = Minecraft.getInstance();
            net.minecraft.world.item.Item.TooltipContext ctx = mc.level != null
                    ? net.minecraft.world.item.Item.TooltipContext.of(mc.level)
                    : net.minecraft.world.item.Item.TooltipContext.EMPTY;
            List<Component> lines = stack.getTooltipLines(ctx, mc.player, net.minecraft.world.item.TooltipFlag.NORMAL);
            for (Component c : lines) {
                Matcher m = WORTH_TILDE.matcher(c.getString());
                if (m.find()) return m.group(1).trim();
            }
            for (Component c : lines) {
                Matcher m = WORTH_DOLLAR.matcher(c.getString());
                if (m.find()) return m.group(1).trim();
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    // ---------- text helpers ----------

    public static String itemName(Auction a) {
        String n = a.stack.getHoverName().getString();
        return a.count > 1 ? a.count + "x " + n : n;
    }

    public static String lastNote(Auction a) {
        if (a.lastResult == null) return "";
        return switch (a.lastResult) {
            case NEW_HIGH -> "";
            case BELOW_MIN -> " (below min, not a bid)";
            case NOT_HIGHER -> " (not the top bid)";
        };
    }

    public static List<Component> statusLines(Auction a) {
        List<Component> out = new ArrayList<>();
        out.add(prefix()
                .append(lit("Item: ", ChatFormatting.GRAY)).append(lit(itemName(a), ChatFormatting.YELLOW))
                .append(lit("  Min: ", ChatFormatting.GRAY)).append(lit(Auction.money(a.minimum), ChatFormatting.GREEN))
                .append(lit("  Time: ", ChatFormatting.GRAY)).append(lit(Auction.time(a.timeLeftMs()), ChatFormatting.AQUA)));
        if (a.worth >= 0) {
            out.add(prefix().append(lit("Worth: ", ChatFormatting.GRAY))
                    .append(lit("~" + Auction.money(a.worth), ChatFormatting.WHITE)));
        }
        out.add(prefix().append(lit("Highest bidder: ", ChatFormatting.GRAY))
                .append(a.highestBidder == null
                        ? lit("none yet", ChatFormatting.DARK_GRAY)
                        : lit(a.highestBidder + " - " + Auction.money(a.highestAmount), ChatFormatting.GOLD)));
        out.add(prefix().append(lit("Last paid: ", ChatFormatting.GRAY))
                .append(a.lastPaidName == null
                        ? lit("none yet", ChatFormatting.DARK_GRAY)
                        : lit(a.lastPaidName + " - " + Auction.money(a.lastPaidAmount) + lastNote(a), ChatFormatting.WHITE)));
        return out;
    }

    private static String shortStatus(Auction a) {
        return "Highest: " + (a.highestBidder == null ? "none" : a.highestBidder + " " + Auction.money(a.highestAmount))
                + " | Last paid: " + (a.lastPaidName == null ? "none" : a.lastPaidName + " " + Auction.money(a.lastPaidAmount));
    }

    private static String publicSummary(Auction a) {
        return "[Auction] " + itemName(a) + " | " + shortStatus(a) + " | " + Auction.time(a.timeLeftMs()) + " left";
    }

    public static MutableComponent prefix() {
        return Component.literal("[Auction] ").withStyle(ChatFormatting.GOLD);
    }

    public static MutableComponent lit(String s, ChatFormatting f) {
        return Component.literal(s).withStyle(f);
    }

    public static void say(Component c) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        boolean prev = sayingNow;
        sayingNow = true;
        try {
            mc.player.displayClientMessage(c, false);
        } finally {
            sayingNow = prev;
        }
    }

    public static void publicSay(String msg) {
        if (!config.announce) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.player.connection == null) return;
        if (msg.startsWith("/")) msg = "[Auction]" + msg;
        if (msg.length() > 250) msg = msg.substring(0, 250);
        mc.player.connection.sendChat(msg);
    }

    private static void playPing() {
        try {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) mc.player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
        } catch (Throwable ignored) {
        }
    }
}
